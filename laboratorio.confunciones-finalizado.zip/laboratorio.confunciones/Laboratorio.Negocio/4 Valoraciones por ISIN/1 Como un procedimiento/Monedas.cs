﻿namespace Negocio.ValoracionesPorISIN.ComoUnProcedimiento
{
    public enum Monedas
    {
        UDES,
        Colon,
        Dolar
    }
}
