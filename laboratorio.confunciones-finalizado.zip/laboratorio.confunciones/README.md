# laboratorio.confunciones
Laboratorio para aplicar el refactoring de extraer funciones a partir de un procedimiento.
